﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int y1 = int.Parse(Console.ReadLine());
            int y2 = int.Parse(Console.ReadLine());
            int nr = 0;
            for (int i = y1; i <= y2; i++)
            {
                if (i % 4 == 0 && i % 100 != 0 && i % 400 != 0)
                {
                    nr++;
                }
            }
            Console.WriteLine(nr);
        }
    }
}
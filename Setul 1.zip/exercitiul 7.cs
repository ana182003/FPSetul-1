﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _ex_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a, b, aux;
            string[] t = Console.ReadLine().Split(' ');
            a = int.Parse(t[0]);
            b = int.Parse(t[1]);
            {
                aux = a;
                a = b;
                b = aux;
            }
            Console.WriteLine(a + " " + b);
            Console.ReadKey();
        }

    }
}
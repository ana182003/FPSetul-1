﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex18
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int d = 2;
            int p = 0;
            int ok = 0;
            while (n != 1)
            {
                p = 0;
                while (n % d == 0)
                {
                    n = n / d;
                    p++;
                }
                if (p > 0 && ok == 1)
                {
                    Console.Write("+" + d + "^" + p);
                }
                if (p > 0 && ok == 0)
                {
                    Console.Write(d + "^" + p);
                    ok = 1;
                }
                d++;
            }
        }
    }
}
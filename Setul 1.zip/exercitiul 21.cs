﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex21
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int i = 1;
            int j = 1024;
            while (j != n)
            {
                Console.WriteLine($"Este {n} mai mare decat {i} si mai mic decat {j / 2}? ");
                if (n > i && n < j / 2)
                {
                    j = j / 2;
                }
                else
                {
                    i = i++;
                }
                Console.ReadKey();
            }
        }
    }
}

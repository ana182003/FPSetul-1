﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            if (n == 2)
            {
                Console.WriteLine("Este prim");
            }
            if (n == 1)
            {
                Console.WriteLine("Nu este prim");
            }
            for (int d = 2; d <= Math.Sqrt(n); d++)
            {
                if (n % d == 0)
                {
                    Console.WriteLine("Nu este prim");
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex17
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] t = Console.ReadLine().Split(' ');
            int a = int.Parse(t[0]);
            int b = int.Parse(t[1]);
            int r = 0;
            int a1 = a;
            int b1 = b;
            int cmmmc = 0;
            while (b != 0)
            {
                r = a % b;
                a = b;
                b = r;
            }
            Console.WriteLine("Cel mai mare divizor comun este " + a);
            cmmmc = (a1 * b1) / a;
            Console.WriteLine("Cel mai mic multiplu comun este " + cmmmc);
        }
    }
}


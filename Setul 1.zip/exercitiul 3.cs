﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _ex_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            float n = float.Parse(Console.ReadLine());
            float k = float.Parse(Console.ReadLine());
            if (n % k == 0)
            {
                Console.WriteLine("{0} divide cu {1}", n, k);
            }
            else
            {
                Console.WriteLine(n + " nu se divide cu" + k);
            }
            Console.ReadKey();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _ex_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n, k;
            n = Convert.ToInt32(Console.ReadLine());
            k = Convert.ToInt32(Console.ReadLine());
            while (k != 1)
            {
                n /= 10;
                k--;
            }
            Console.WriteLine(n % 10);
        }
    }
}
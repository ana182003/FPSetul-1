﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex_2
{

    internal class Program
    {
        static void Main(string[] args)
        {
            //ax^2 + bx + c = 0
            float a = float.Parse(Console.ReadLine());
            float b = float.Parse(Console.ReadLine());
            float c = float.Parse(Console.ReadLine());
            float d = b * b - 4 * a * c;
            if (d >= 0)
            {
                float x1 = (-b - (float)Math.Sqrt(d)) / (2 * a);
                float x2 = (-b + (float)Math.Sqrt(d)) / (2 * a);
                Console.WriteLine(x1 + " " + x2);
            }
            else
            {
                Console.WriteLine("Ecuatia nu are solutii");
            }
            Console.ReadKey();







        }

    }
}






﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int inv = 0;
            int a = n;
            while (n != 0)
            {
                inv = inv * 10 + n % 10;
                n = n / 10;
            }
            if (inv == a)
            {
                Console.WriteLine("Numarul este palindrom");
            }
            else
                Console.WriteLine("Numarul nu este palindrom");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _ex_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            if (a + b > c && a + c > b && c + b > a)
            {
                Console.WriteLine("{0}, {1} si {2} pot fi laturile unui triunghi", a, b, c);
            }
            else
            {
                Console.WriteLine("{0}, {1} si {2} pot fi laturile unui triunghi", a, b, c);
            }
            Console.ReadKey();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            for (int d = 2; d <= n; d++)
            {
                if (n % d == 0)
                    Console.WriteLine(d);
            }
        }
    }
}
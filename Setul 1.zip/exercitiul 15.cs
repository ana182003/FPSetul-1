﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());

            if (a > b) { a = a + b; b = a - b; a = a - b; }
            if (a > c) { a = a + c; c = a - c; a = a - c; }
            if (b > c) { b = b + c; c = b - c; b = b - c; }
            Console.WriteLine($"{a} {b} {c}");
        }
    }
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _ex_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int y = int.Parse(Console.ReadLine());
            if ((y % 400 == 0) || (y % 4 == 0 && y % 100 != 0))
            {
                Console.WriteLine(y + " este an bisect");
            }
            else { Console.WriteLine(y + " nu este an bisect"); }
            Console.ReadKey();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _ex_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            string[] t = Console.ReadLine().Split(' ');
            a = int.Parse(t[0]);
            b = int.Parse(t[1]);
            a = a + b;
            b = a - b;
            a = a - b;
            Console.WriteLine(a + " " + b);
            Console.ReadKey();
        }
    }
}
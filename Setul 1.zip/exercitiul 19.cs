﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex19
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] a = new int[10];
            int temp = n;
            int s = 0;
            while (temp > 0)
            {
                int aux = temp % 10;
                a[aux]++;
                temp /= 10;
            }
            for (int i = 0; i < 10; i++)
            {
                if (a[i] != 0)
                    s++;
            }
            if (s == 2)
                Console.WriteLine("Numarul " + n + " este format din doua cifre care se repeta");
            else
                Console.WriteLine("Numarul " + n + " nu este format din doua cifre care se repeta");
        }
    }
}